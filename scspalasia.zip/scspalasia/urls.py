from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name='index'),
    path('viewstudent',views.viewstudent,name='viewstudent'),
    path('findstudent',views.findstudent,name='findstudent'),
    path('deletestudent',views.deletestudent,name='deletestudent')
    
]