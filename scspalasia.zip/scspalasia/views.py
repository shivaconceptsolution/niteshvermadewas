from django.shortcuts import render,redirect
from .models import Student,Register
def index(request):
    if request.method=="POST":
        obj = Student(rno=request.POST["txtrno"],sname=request.POST["txtname"],branch=request.POST["txtbranch"],fees=request.POST["txtfees"])
        obj.save()
        return render(request,"scspalasia/student.html",{"res":"student added successfully"})
    return render(request,"scspalasia/student.html")
def viewstudent(request):
    obj = Student.objects.all()
    return render(request,"scspalasia/viewstudent.html",{"res":obj}) 
def findstudent(request):
   data = Student.objects.get(pk=request.GET["q"])
   if request.method=="POST":
      data.rno = request.POST["txtrno"]
      data.sname=request.POST["txtname"]
      data.branch = request.POST["txtbranch"]
      data.fees = request.POST["txtfees"]
      data.save()
      return redirect('viewstudent')
   return render(request,"scspalasia/findstudent.html",{"res":data}) 

def deletestudent(request):
     data = Student.objects.get(pk=request.GET["q"]) 
     if request.method=="POST":
        data.delete()
        return redirect('viewstudent')     
     return render(request,"scspalasia/deletestudent.html",{"res":data})
def register(request):
    if request.method=="POST":
        r = Register(username=request.POST["txtuser"],password=request.POST["txtpass"],email=request.POST["txtemail"],mobile=request.POST["txtmobile"])
        r.save()
        return render(request,"scspalasia/register.html",{"key":"Registration Successfully"})
    return render(request,"scspalasia/register.html")     
def login(request):
    if request.method=='POST':
        r = Register.objects.filter(username=request.POST["txtuser"],password=request.POST["txtpass"])
        if(r.count()>0):
            return redirect('viewstudent')
        else:
            return render(request,"scspalasia/login.html",{"key":"Invalid Userid and password"})    
    return render(request,"scspalasia/login.html")    