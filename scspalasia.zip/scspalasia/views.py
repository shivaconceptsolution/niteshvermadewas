from django.shortcuts import render,redirect
from .models import Student
def index(request):
    if request.method=="POST":
        obj = Student(rno=request.POST["txtrno"],sname=request.POST["txtname"],branch=request.POST["txtbranch"],fees=request.POST["txtfees"])
        obj.save()
        return render(request,"scspalasia/student.html",{"res":"student added successfully"})
    return render(request,"scspalasia/student.html")
def viewstudent(request):
    obj = Student.objects.all()
    return render(request,"scspalasia/viewstudent.html",{"res":obj}) 
def findstudent(request):
   data = Student.objects.get(pk=request.GET["q"])
   if request.method=="POST":
      data.rno = request.POST["txtrno"]
      data.sname=request.POST["txtname"]
      data.branch = request.POST["txtbranch"]
      data.fees = request.POST["txtfees"]
      data.save()
      return redirect('viewstudent')
   return render(request,"scspalasia/findstudent.html",{"res":data}) 

def deletestudent(request):
     data = Student.objects.get(pk=request.GET["q"]) 
     if request.method=="POST":
        data.delete()
        return redirect('viewstudent')     
     return render(request,"scspalasia/deletestudent.html",{"res":data})