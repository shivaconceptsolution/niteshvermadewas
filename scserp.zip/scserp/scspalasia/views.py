from django.shortcuts import render
from .models import Student
def index(request):
    if request.method=="POST":
        obj = Student(rno=request.POST["txtrno"],sname=request.POST["txtname"],branch=request.POST["txtbranch"],fees=request.POST["txtfees"])
        obj.save()
        return render(request,"scspalasia/student.html",{"res":"student added successfully"})
    return render(request,"scspalasia/student.html")
